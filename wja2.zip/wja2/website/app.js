const baseURL = 'http://api.openweathermap.org/data/2.5/weather?zip=';
const apiKey = ",&appid=27f7f63801b92c3155f78e627aa88884&units=metric";
const server = "http://127.0.0.1:2100";
const generate = document.querySelector("#generate");
const zipp = document.querySelector("#zip");
const feeling = document.querySelector("#feelings");
let d = new Date();
let newDate = d.getMonth()+'.'+ d.getDate()+'.'+ d.getFullYear();
const temp = document.querySelector("#temp");
const error = document.getElementById("error");
const country = document.querySelector("#country");

const generateUse = () => { 
  const zipp = document.getElementById("zip").value;
  const feeling = document.getElementById("feelings").value;


  getWeatherData(zipp).then((data) => {
    
    if (data) {
      const { main: { temp },name: country,weather: [{ description  }], } = data;

      const info = {
        newDate,country,temp: Math.round(temp),  description, feeling };

      postData( server + "/add", info);

      updatingUI();
      document.getElementById('entry').style.opacity = 1;
    }
  });
};

document.getElementById("generate").addEventListener("click", generateUse);


const getWeatherData = async (zipp) => {
  try {
    const res = await fetch(baseURL + zipp + apiKey);
    const data = await res.json();

    if (data.cod != 200) {
      
      error.innerHTML = data.message;
      setTimeout(_=> error.innerHTML = '', 2000)
      throw `${data.message}`;
    }

    return data;
  } catch (error) {
    console.log(error);
  }
};
async function getZipCodeInformation(zipCode)
{
  return await
  (await fetch(`https://api.openweathermap.org/data/2.5/weather?zip=${zipCode}${apiKey}`))
  I.json()
}

const postData = async (url = "", info = {}) => {
  const res = await fetch(url, {
    method: "POST",headers: { "Content-Type": "application/json",  }, body: JSON.stringify(info), });

  try {
    const newData = await res.json();
    console.log(`You just keeped`, newData);
    return newData;
  } catch (error) {
    console.log(error);
  }
};

const updatingUI = async () => {
    const res = await fetch(server + "/all");
    try {
        const allData = await res.json();

        document.getElementById("date").innerHTML = `Your Date is: ${allData.newDate}`;
        document.getElementById("country").innerHTML = allData.country;
        document.getElementById("temp").innerHTML = `Your Temprature is : ${allData.temp}  '&degC';`;
        document.getElementById("description").innerHTML = allData.description;
        document.getElementById("content").innerHTML =`I feel : ${allData.feeling}`;
    }
    catch (error) {
      console.log("error", error);
    }}

